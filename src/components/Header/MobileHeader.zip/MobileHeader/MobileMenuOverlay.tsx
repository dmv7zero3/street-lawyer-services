import React, { useEffect, useRef, useState, useCallback } from "react";
import { createPortal } from "react-dom";
import { Link } from "react-router-dom";
import { Instagram, Facebook, Phone, MapPin, Clock } from "lucide-react";
import { gsap } from "gsap";
import {
  PHONE_NUMBER,
  INSTAGRAM_URL,
  FACEBOOK_URL,
} from "@/core/constants/business";

interface MobileMenuOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const NAV_LINKS = [
  { path: "/", label: "Home" },
  { path: "/menu", label: "Menu" },
  { path: "/events", label: "Events" },
  { path: "/catering", label: "Catering" },
  { path: "/contact", label: "Contact" },
] as const;

// Enhanced anti-flicker CSS with performance optimizations
const overlayStyles = `
  .menu-overlay-fixed {
    position: fixed;
    inset: 0;
    z-index: 99999;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    background: radial-gradient(circle at 20% 20%, rgba(0,191,255,0.1) 0%, transparent 40%),
                radial-gradient(circle at 80% 80%, rgba(138,43,226,0.1) 0%, transparent 40%),
                #000;
    transform: translateZ(0);
    will-change: opacity, visibility;
    backface-visibility: hidden;
    contain: layout style paint;
  }
  
  .menu-overlay-fixed.is-animating {
    visibility: visible;
    pointer-events: auto;
  }
  
  .menu-overlay-fixed.is-open {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
  }
  
  .menu-content-wrapper {
    opacity: 0;
    transform: translateY(40px) translateZ(0);
    will-change: opacity, transform;
  }
  
  .menu-nav-item {
    opacity: 0;
    transform: translateY(32px) translateZ(0);
    will-change: opacity, transform;
  }
  
  /* Performance: Remove will-change after animations */
  .menu-overlay-fixed:not(.is-animating) .menu-content-wrapper,
  .menu-overlay-fixed:not(.is-animating) .menu-nav-item {
    will-change: auto;
  }
`;

// Singleton style injection to prevent duplicates
let stylesInjected = false;
const injectStyles = () => {
  if (stylesInjected || typeof window === "undefined") return;

  const existingStyle = document.getElementById("mobile-menu-styles");
  if (!existingStyle) {
    const styleEl = document.createElement("style");
    styleEl.id = "mobile-menu-styles";
    styleEl.textContent = overlayStyles;
    document.head.appendChild(styleEl);
    stylesInjected = true;
  }
};

// Main component that uses Portal
const MobileMenuOverlay: React.FC<MobileMenuOverlayProps> = (props) => {
  // Inject styles immediately
  injectStyles();

  if (typeof window === "undefined") return null;
  return createPortal(<MobileMenuOverlayContent {...props} />, document.body);
};

const MobileMenuOverlayContent: React.FC<MobileMenuOverlayProps> = ({
  isOpen,
  onClose,
}) => {
  // Refs for GSAP
  const overlayRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const navContainerRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<gsap.core.Timeline | null>(null);

  // Track animation state
  const [isAnimating, setIsAnimating] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);

  // Memoized close handler to prevent unnecessary re-renders
  const handleClose = useCallback(() => {
    if (!isAnimating) {
      onClose();
    }
  }, [onClose, isAnimating]);

  // Body scroll lock with improved cleanup
  useEffect(() => {
    if (!isOpen) return;

    const originalOverflow = document.body.style.overflow;
    const originalPaddingRight = document.body.style.paddingRight;
    const scrollBarWidth =
      window.innerWidth - document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    document.body.style.paddingRight = `${scrollBarWidth}px`;

    return () => {
      document.body.style.overflow = originalOverflow;
      document.body.style.paddingRight = originalPaddingRight;
    };
  }, [isOpen]);

  // Escape key handler with improved dependencies
  useEffect(() => {
    if (!isOpen) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !isAnimating) {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [isOpen, isAnimating, onClose]);

  // Main animation logic - optimized for performance
  useEffect(() => {
    const overlay = overlayRef.current;
    const content = contentRef.current;
    const navContainer = navContainerRef.current;

    if (!overlay || !content) return;

    // Kill any existing animation
    if (animationRef.current) {
      animationRef.current.kill();
      animationRef.current = null;
    }

    if (isOpen) {
      // OPENING ANIMATION
      setShouldRender(true);
      setIsAnimating(true);

      // Set up DOM state immediately - this is the key anti-flicker fix
      overlay.classList.add("is-animating");

      // Get nav items safely with performance consideration
      const navItems = navContainer?.querySelectorAll(".menu-nav-item") || [];

      // Force initial state with GSAP - prevents flicker completely
      gsap.set(overlay, {
        opacity: 0,
        visibility: "visible",
        pointerEvents: "auto",
        force3D: true,
        clearProps: "transform",
      });

      gsap.set(content, {
        opacity: 0,
        y: 40,
        force3D: true,
      });

      gsap.set(navItems, {
        opacity: 0,
        y: 32,
        force3D: true,
      });

      // Create optimized opening timeline
      const tl = gsap.timeline({
        defaults: {
          ease: "power2.out",
          force3D: true,
        },
        onComplete: () => {
          overlay.classList.add("is-open");
          setIsAnimating(false);

          // Performance: Remove will-change after animation
          gsap.set([overlay, content, ...navItems], {
            clearProps: "will-change",
          });
        },
      });

      // Staggered animation sequence
      tl.to(overlay, {
        opacity: 1,
        duration: 0.3,
      })
        .to(
          content,
          {
            opacity: 1,
            y: 0,
            duration: 0.4,
          },
          "-=0.2"
        )
        .to(
          navItems,
          {
            opacity: 1,
            y: 0,
            duration: 0.3,
            stagger: 0.08,
          },
          "-=0.3"
        );

      animationRef.current = tl;
    } else {
      // CLOSING ANIMATION
      if (!shouldRender) return; // Already closed

      setIsAnimating(true);
      overlay.classList.remove("is-open");

      const navItems = navContainer?.querySelectorAll(".menu-nav-item") || [];

      // Create optimized closing timeline
      const tl = gsap.timeline({
        defaults: {
          ease: "power2.in",
          force3D: true,
        },
        onComplete: () => {
          overlay.classList.remove("is-animating");
          gsap.set(overlay, {
            visibility: "hidden",
            pointerEvents: "none",
            clearProps: "will-change,transform",
          });
          setShouldRender(false);
          setIsAnimating(false);
        },
      });

      // Reverse staggered animation
      tl.to(navItems, {
        opacity: 0,
        y: -20,
        duration: 0.2,
        stagger: 0.03, // Faster stagger for closing
      })
        .to(
          content,
          {
            opacity: 0,
            y: -30,
            duration: 0.25,
          },
          "-=0.15"
        )
        .to(
          overlay,
          {
            opacity: 0,
            duration: 0.25,
          },
          "-=0.2"
        );

      animationRef.current = tl;
    }

    // Cleanup function
    return () => {
      if (animationRef.current) {
        animationRef.current.kill();
        animationRef.current = null;
      }
    };
  }, [isOpen, shouldRender]);

  // Don't render if not needed
  if (!shouldRender && !isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  const handleNavClick = (e: React.MouseEvent) => {
    // Small delay to allow visual feedback before closing
    setTimeout(handleClose, 100);
  };

  return (
    <div
      ref={overlayRef}
      className="menu-overlay-fixed"
      onClick={handleBackdropClick}
    >
      {/* Optimized background particles */}
      <div className="absolute inset-0 pointer-events-none opacity-30">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-white rounded-full"
            style={{
              width: "2px",
              height: "2px",
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `pulse ${2 + Math.random() * 2}s infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div
        ref={contentRef}
        className="relative flex flex-col h-full p-6 overflow-y-auto menu-content-wrapper"
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          disabled={isAnimating}
          className="absolute z-10 p-3 transition-all duration-200 border-none rounded-full cursor-pointer top-6 right-6 bg-white/10 backdrop-blur-sm hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Close menu"
          type="button"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-white"
          >
            <line x1="6" y1="6" x2="18" y2="18" />
            <line x1="18" y1="6" x2="6" y2="18" />
          </svg>
        </button>

        {/* Logo Section */}
        <div className="flex justify-center pt-8 pb-6">
          <div className="text-center">
            <h1 className="m-0 text-3xl tracking-widest sm:text-4xl md:text-5xl font-bebas text-electric-blue">
              MOON LOUNGE
            </h1>
            <p className="m-0 mt-2 text-base font-light tracking-wide sm:text-lg md:text-xl text-moon-gold font-poppins">
              Where Night Comes Alive
            </p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav
          ref={navContainerRef}
          className="flex flex-col items-center justify-center flex-1 gap-2 pb-8"
        >
          {NAV_LINKS.map((link) => (
            <div
              key={link.path}
              className="flex justify-center w-full menu-nav-item"
            >
              <Link
                to={link.path}
                onClick={handleNavClick}
                className="relative px-6 py-5 text-2xl tracking-wide text-center transition-all duration-200 rounded-lg sm:text-3xl md:text-4xl font-bebas text-moon-silver hover:bg-white/10 hover:text-white focus:outline-none focus:ring-2 focus:ring-electric-blue focus:ring-opacity-50"
                style={{
                  fontFamily: "Bebas Neue, cursive",
                  letterSpacing: "0.1em",
                }}
              >
                {link.label}
              </Link>
            </div>
          ))}
        </nav>

        {/* Social Media */}
        <div className="py-6">
          <div className="flex justify-center gap-8 mb-6">
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 transition-all duration-200 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-electric-blue"
              aria-label="Follow us on Instagram"
            >
              <Instagram className="w-6 h-6 text-white" />
            </a>
            <a
              href={FACEBOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 transition-all duration-200 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-electric-blue"
              aria-label="Follow us on Facebook"
            >
              <Facebook className="w-6 h-6 text-white" />
            </a>
            <a
              href={`tel:${PHONE_NUMBER.replace(/[^\d]/g, "")}`}
              className="p-3 transition-all duration-200 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-electric-blue"
              aria-label="Call us"
            >
              <Phone className="w-6 h-6 text-white" />
            </a>
          </div>
        </div>

        {/* Contact Info */}
        <div className="pb-6">
          <div className="p-4 border border-white/10 bg-white/5 rounded-xl backdrop-blur-sm">
            <div className="flex items-center justify-center gap-6 mb-2 text-sm sm:text-base md:text-lg text-moon-silver">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-moon-gold" />
                <span>Sterling, VA</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-moon-gold" />
                <span>Open until 2 AM</span>
              </div>
            </div>
            <p className="m-0 text-xs font-light text-center sm:text-sm md:text-base text-moon-silver font-poppins">
              Premium hookah • Craft cocktails • Mediterranean cuisine
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileMenuOverlay;
